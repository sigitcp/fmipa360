<?php
$conn = mysqli_connect("localhost","root","","fmipa360");


// if (!$conn) {
//     die("Koneksi gagal: " . mysqli_connect_error());
// }
// echo "Koneksi berhasil";
// mysqli_close($conn);
?>