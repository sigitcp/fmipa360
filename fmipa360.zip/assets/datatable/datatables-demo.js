// Call the dataTables jQuery plugin
$(document).ready(function() {
  $('#gbr').DataTable();
});

$(document).ready(function() {
  $('#glm').DataTable();
});

$(document).ready(function() {
  $('#bio').DataTable();
});

$(document).ready(function() {
  $('#sis').DataTable();
});

