$(document).ready(function () {
    $('#dataTable').DataTable({
        paging: false,
        ordering: false,
        info: false,
        language: {
            searchPlaceholder: "Search name room",
            search: ""}
            
    });
});
